/******************************************************************************
Macro definitions
******************************************************************************/

#define SW1_MASK 0x40	// Corresponding to bit 6 in register
#define SW2_MASK 0x10	// Corresponding to bit 4 in register
#define SW3_MASK 0x20	// Corresponding to bit 5 in register
#define OFF 			(0)
#define ON 			(1)

#define PORT7 (unsigned char *)0xFFF07
#define PORTPM7 (unsigned char *)0xFFF27

/******************************************************************************
* Global Function Prototypes
******************************************************************************/

boolean pollingSW1 ();
boolean pollingSW2 ();
boolean pollingSW3 ();

